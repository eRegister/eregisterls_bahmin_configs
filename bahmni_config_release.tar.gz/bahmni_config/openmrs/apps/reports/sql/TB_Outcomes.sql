SELECT grping,
IF(Id IS NULL, 0, SUM(IF(outcome = 'total_screened', 1, 0))) AS Completed,
IF(Id IS NULL, 0, SUM(IF(outcome = 'with_signs', 1, 0))) AS Cured,
IF(Id IS NULL, 0, SUM(IF(outcome = 'with_signs', 1, 0))) AS Died,
IF(Id IS NULL, 0, SUM(IF(outcome = 'signs_bacteriology', 1, 0))) AS Lost,
IF(Id IS NULL, 0, SUM(IF(outcome = 'with_signs', 1, 0))) AS Failed,
IF(Id IS NULL, 0, SUM(IF(outcome = 'with_signs', 1, 0))) AS resistant

FROM 
(
SELECT Id, outcome,grping
FROM
(	-- CASE OUTCOMES FROM ALL COMPLETED
                (select distinct o.person_id AS Id , 'completed' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 2242
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'completed' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2242
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								
						UNION
						
						-- CURED
						(select distinct o.person_id AS Id , 'cured' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 1068
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'cured' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 1068
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								
							UNION
							
							-- DIED
							(select distinct o.person_id AS Id , 'died' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 3650
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'died' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3650
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								
								UNION
								-- LTFU
								
								(select distinct o.person_id AS Id , 'Lost' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 2302
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Lost' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 2302
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								
								UNION
								
								-- FAILED
								
								(select distinct o.person_id AS Id , 'Failed' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 3793
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'Failed' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3793
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								
								-- NOT EVALUATED
								UNION
								(select distinct o.person_id AS Id , 'resistant' as outcome, 'New and relapse' as grping
                                        from obs o

                                                INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
												AND o.person_Id in (select person_id 
													from obs
													where (concept_id = 3785 and value_coded in  (1034,1084)
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE)))
												)
												
                                                INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                                                  WHERE concept_id = 3792 and value_coded = 3794
													AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
													AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
							UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'Retreatment Excluding Relapse' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3780 and value_coded in (3786,1037))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'All HIV Positive' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where concept_id in (4153,1158)
												and obs.person_id in (select person_id from obs where concept_id = 2249)
																		AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
																		AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'All Children' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 14
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'All Adolescents' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select id
													FROM
													( 
													select distinct o.person_id AS Id,
													floor(datediff(CAST('2019-01-31' AS DATE), person.birthdate)/365) AS Age								   
													from obs o
													INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
													INNER JOIN patient_identifier ON patient_identifier.patient_id = person.person_id AND patient_identifier.identifier_type = 3	
													) as a
												WHERE age <= 19 and age >= 10
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'Female' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from person
												where gender = 'F'
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3667)
												AND MONTH(obs_datetime) = MONTH(CAST('#endDate#' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('#endDate#' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'Ex miner' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3778)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'Factory' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded = 3669)
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
								UNION
								
			                (select distinct o.person_id AS Id , 'resistant' as outcome, 'Staff & inmates' as grping
                             from obs o

                             INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
							 AND o.person_Id in (select person_id 
												from obs
												where (concept_id = 3776 and value_coded in (3779,3671))
												AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
												AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
												)
							INNER JOIN patient_identifier ON patient_identifier.patient_id = o.person_id AND patient_identifier.identifier_type = 3
                            WHERE concept_id = 3792 and value_coded = 3794
							AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
							AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
                                )
				) as B

) AS BB
group by grping