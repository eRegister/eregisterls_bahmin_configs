SELECT exam_time,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'total_visits', 1, 0))) AS total_visits,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'Vitamin_A', 1, 0))) AS Vitamin_A,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'family_planning', 1, 0))) AS family_planning,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'cervical_cancer', 1, 0))) AS cervical_cancer,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'breast_lactating', 1, 0))) AS breast_lactating,
IF(Id IS NULL, 0, SUM(IF(PNC_Visit = 'MUAC_Under_23', 1, 0))) AS MUAC_Under_23
FROM 
(
SELECT Id, PNC_Visit,exam_time
FROM
-- MOTHER
	(	
		-- total follow up PNC visits
		select Id,total_visits as PNC_Visit,6weeks as exam_time
		from
			(select o.person_id as Id,count(concept_id) as total_visits,'6Weeks'
			from obs o
			INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
			AND o.person_Id in (select person_id from obs where concept_id = 4398)
			where concept_id = 2466 and value_coded = 2462
			AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
			AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
			
		)visits

UNION
-- total follow up PNC visits
select Id,total_visits as PNC_Visit,14weeks as exam_time
from
	(select o.person_id as Id,count(concept_id) as total_visits,'14Weeks'
	from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
	where concept_id = 2466 and value_coded = 2462
	AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
	AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
	
)visit14

UNION
-- total follow up PNC visits
select Id,total_visits as PNC_Visit,6Mnths as exam_time
from
		(select o.person_id as Id,count(concept_id) as total_visits,'6Mnths'
		from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
		where concept_id = 2466 and value_coded = 2462
		AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
		AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
		
		)visit6

UNION
-- Vitamin A within 6 weeks after delivery
(select o.person_id as Id, 'Vitamin_A' as PNC_Visit,'6Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where concept_id = 2471
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Vitamin A within 6 weeks after delivery
(select o.person_id as Id, 'Vitamin_A' as PNC_Visit,'14Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
where concept_id = 2471
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Vitamin A within 6 weeks after delivery
(select o.person_id as Id, 'Vitamin_A' as PNC_Visit,'6Mnths' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
where concept_id = 2471
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Family Planning counselling at 6 weeks
(select o.person_id as Id,'family_planning' as PNC_Visit,'6Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where concept_id = 4350 and value_coded  = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Family Planning counselling at 6 weeks
(select o.person_id as Id,'family_planning' as PNC_Visit,'14Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
where concept_id = 4350 and value_coded  = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)
UNION
-- Family Planning counselling at 6 weeks
(select o.person_id as Id,'family_planning' as PNC_Visit,'6Mnths' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
where concept_id = 4350 and value_coded  = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Micro-nutrient within 14 weeks of delivery 
(select o.person_id as Id, 'nutrients_supplied' as PNC_Visit,'6Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where concept_id = 4437 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Micro-nutrient within 14 weeks of delivery 
(select o.person_id as Id, 'nutrients_supplied' as PNC_Visit,'14Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
where concept_id = 4437 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Micro-nutrient within 14 weeks of delivery 
(select o.person_id as Id, 'nutrients_supplied' as PNC_Visit,'6Mnths' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
where concept_id = 4437 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Cervical cancer screening at 14 weeks 
(select o.person_id as Id, 'cervical_cancer' as PNC_Visit,'6Weeks' as 'exam_time' 
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where (concept_id = 4445 and value_coded = 2146)
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Cervical cancer screening at 14 weeks 
(select o.person_id as Id, 'cervical_cancer' as PNC_Visit,'14Weeks' as 'exam_time' 
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
where (concept_id = 4445 and value_coded = 2146)
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Cervical cancer screening at 14 weeks 
(select o.person_id as Id, 'cervical_cancer' as PNC_Visit,'6Mnths' as 'exam_time' 
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
where (concept_id = 4445 and value_coded = 2146)
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Lactating mother at 14 weeks
(select o.person_id as Id,'breast_lactating' as PNC_Visit,'6Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where concept_id = 4421 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Lactating mother at 14 weeks
(select o.person_id as Id,'breast_lactating' as PNC_Visit,'14Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4400)
where concept_id = 4421 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- Lactating mother at 14 weeks
(select o.person_id as Id,'breast_lactating' as PNC_Visit,'6Mnths' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4401)
where concept_id = 4421 and value_coded = 2146
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- MUAC < 23 cm in lactating mothers at 14 weeks
(select o.person_id as Id,'MUAC_Under_23' as PNC_Visit,'6Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where (concept_id  = 4435 and value_coded = 2146)
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- MUAC < 23 cm in lactating mothers at 14 weeks
(select o.person_id as Id,'MUAC_Under_23' as PNC_Visit,'14Weeks' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
where (concept_id  = 4435 and value_coded = 2146)
AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
)

UNION
-- MUAC < 23 cm in lactating mothers at 14 weeks
(select o.person_id as Id,'MUAC_Under_23' as PNC_Visit,'6Mnths' as 'exam_time'
from obs o
		INNER JOIN person ON person.person_id = o.person_id AND person.voided = 0
		AND o.person_Id in (select person_id from obs where concept_id = 4398)
		where (concept_id  = 4435 and value_coded = 2146)
		AND MONTH(obs_datetime) = MONTH(CAST('2019-01-31' AS DATE))
		AND YEAR(obs_datetime) =  YEAR(CAST('2019-01-31' AS DATE))
		)
		
	)AS B
)AS C
group by exam_time